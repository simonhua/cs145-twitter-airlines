To generate the "data.xlsx" by yourself, do the following:

1. Download Node JS (https://nodejs.org/en/)
2. In terminal, type "npm install"
3. Then type "npm start"
